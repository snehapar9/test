Microsoft Azure CLI 'containerapp' Extension


